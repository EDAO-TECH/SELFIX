#!/usr/bin/env python3
import argparse

def main():
    print("🔧 Idea: Create Cli To List All Sandboxed Ideas
 is running...")

if __name__ == "__main__":
    main()
